import pygame

import math
from pygame import mixer 
from pygame.locals import *
from sys import exit
from random import *
from math import *

_songs = ['sound01.mp3', 'sound02.mp3', 'sound03.mp3' ]

class dim4:
    def __init__(self, (x, y)  ):
      self.x =  x
      self.y = y
      self.rx =  5
      self.ry = 5
      
      self.atime= 0

      self.wtime= 0
      self.color = (0,255,0)
      
    def pos(self):
        return (self.x,self.y)

def trg01( one):
  if (one[0]>=100 and one[0]<=200) and (one[1]>=200 and one[1]<=300) :
    print "HIT 01"
    return 1
  else:
    print "Miss 01"
    return 0

def trg02( one):
  if (one[0]>=250 and one[0]<=350) and (one[1]>=200 and one[1]<=300) :
    print "HIT 02"
    return 1
  else:
    print "Miss 02"
    return 0

def trg03( one):
  if (one[0]>=400 and one[0]<=500) and (one[1]>=200 and one[1]<=300) :
    print "HIT 03"
    return 1
  else:
    print "Miss 03"
    return 0


def trg04( one):
  if (one[0]>=100 and one[0]<=200) and (one[1]>=400 and one[1]<=500) :
    print "HIT 04"
    return 1
  else:
    print "Miss 04"
    return 0

def trg05( one):
  if (one[0]>=250 and one[0]<=350) and (one[1]>=400 and one[1]<=500) :
    print "HIT 05"
    return 1
  else:
    print "Miss 05"
    return 0

def trg06( one):
  if (one[0]>=400 and one[0]<=500) and (one[1]>=400 and one[1]<=500) :
    print "HIT 06"
    return 1
  else:
    print "Miss 06"
    return 0

      
pygame.init()
mixer.init()
state = 0
xsc,ysc=940,680
screen = pygame.display.set_mode((xsc,ysc), 0, 32)
pygame.display.set_caption("Color Clock")
font= pygame.font.SysFont("arial", 24)
colors=[(255,0,0),(0,255,0),(0,0,255)]
clock = pygame.time.Clock()
tick=30
speed=500
frame_no=0
x1,x2=0,0
para=0

backImg = pygame.image.load('stage02.jpg')
Img=[]
Img.append( pygame.image.load('logo01.jpg') )
Img.append( pygame.image.load('logo02.jpg') )
Img.append( pygame.image.load('logo03.jpg') )
Img.append( pygame.image.load('logo04.jpg') )
Img.append( pygame.image.load('logo05.jpg') )
Img.append( pygame.image.load('logo06.jpg') )
Img.append( pygame.image.load('logo07.jpg') )
Img.append( pygame.image.load('logo08.jpg') )
Img.append( pygame.image.load('logo09.jpg') )
Img.append( pygame.image.load('logo10.jpg') )
Img.append( pygame.image.load('logo11.jpg') )
Img.append( pygame.image.load('logo12.jpg') )


WHITE = (255, 255, 255)
effect1 = pygame.mixer.Sound('sound01.mp3')
effect2 = pygame.mixer.Sound('sound02.mp3')

mixer.music.load("sound01.mp3")  
 
mixer.music.set_volume(0.7)

msg01="DaVinci"
msg02="Cray"
sc01=0
sc02=0
birth=0

feed=[0,0,0,0,0,0,0,0,0,0]

while(state ==0):

  screen.fill(WHITE)
  pygame.draw.circle( screen, (255,0,255), pygame.mouse.get_pos(), 50, 1)
  
  
   
    

  for i in range(150,900,150):
    
    pygame.draw.circle( screen, (255,0,255), (i,250), 50, 1)
    pygame.draw.circle( screen, (255,0,255), (i,400), 50, 1)
    if feed[0]==0:
      screen.blit(Img[0], (100, 200))
    else:
      pygame.draw.rect( screen, (255,0,255), Rect((100,200),(100,100)) )
    if feed[1]==0:
      screen.blit(Img[1], (250, 200))
    else:
      pygame.draw.rect( screen, (255,0,255), Rect((250,200),(100,100)) )
    if feed[2]==0:
      screen.blit(Img[2], (400, 200))
    else:
      pygame.draw.rect( screen, (255,0,255), Rect((400,200),(100,100)) )
        

    if feed[3]==0:
      screen.blit(Img[3], (100, 350))
    else:
      pygame.draw.rect( screen, (255,250,5), Rect((100,350),(100,100)) )
    if feed[4]==0:
      screen.blit(Img[4], (250, 350))
    else:
      pygame.draw.rect( screen, (255,250,5), Rect((250,350),(100,100)) )
    if feed[5]==0:
      screen.blit(Img[5], (400, 350))
    else:
      pygame.draw.rect( screen, (255,250,5), Rect((400,350),(100,100)) )
        


    
  for event in pygame.event.get():
    
    
    

    if event.type == QUIT:
      state = 1
    if event.type == KEYDOWN:
      if event.key == K_q:
          state = 1
      if event.key == K_SPACE:
        mixer.music.play()
        pygame.draw.circle( screen, (255,0,255), pygame.mouse.get_pos(), 100, 0)
        
        feed[0] = trg01( pygame.mouse.get_pos() )
        feed[1] = trg02( pygame.mouse.get_pos() )
        feed[2] = trg03( pygame.mouse.get_pos() )
        feed[3] = trg04( pygame.mouse.get_pos() )
        feed[4] = trg05( pygame.mouse.get_pos() )
        feed[5] = trg06( pygame.mouse.get_pos() )
        
       
      if event.key == K_c:
        roll=choice((0,1)  )
        if roll==0:
          effect1.play()
        elif roll==1:
          effect2.play()

          
  


      if event.key == K_z:
        if (para ==0): 
          para=1
        elif (para ==1):
          para=0
      if event.key == K_r:
        tick-=5
      if event.key == K_t:
        tick+=5
        


      if event.key == K_z:
        mixer.music.play()



  time_passed = clock.tick(tick)
  time_seconds=time_passed/1000.0
  birth+=time_seconds
  if birth>=1:
      shuffle(Img)
      birth=0
  distance_moved=time_seconds*speed
          
  if (para ==1): 
    x1+= distance_moved
  elif (para ==0):
    x1-= distance_moved
    

  t1=x1/speed
  d1=(t1)
  text_surface01=font.render(msg01+str(birth), True, (0,0,255))
  text_surface02=font.render(msg02, True, (0,0,255))
  
  screen.blit(text_surface01, (50,580))
  screen.blit(text_surface02, (50,640))
  pygame.display.update()
  
pygame.quit()
